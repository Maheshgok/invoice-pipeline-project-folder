import { FileText, Scan, CheckCircle } from 'lucide-react';

interface AnalysisProgressProps {
  progress: number;
  state: 'uploading' | 'analyzing';
}

export function AnalysisProgress({ progress, state }: AnalysisProgressProps) {
  const steps = [
    { id: 'upload', label: 'Uploading', icon: FileText, threshold: 0 },
    { id: 'analyze', label: 'Analyzing', icon: Scan, threshold: 30 },
    { id: 'complete', label: 'Extracting Data', icon: CheckCircle, threshold: 60 }
  ];

  return (
    <div className="max-w-2xl mx-auto">
      <div className="bg-white rounded-lg border border-gray-200 p-8">
        <h2 className="text-gray-900 mb-6 text-center">Analyzing Invoice</h2>

        <div className="space-y-6">
          <div className="space-y-4">
            {steps.map((step, index) => {
              const Icon = step.icon;
              const isActive = progress >= step.threshold;
              const isCurrent = state === step.id || (state === 'analyzing' && progress >= step.threshold && progress < (steps[index + 1]?.threshold || 100));

              return (
                <div key={step.id} className="flex items-center gap-4">
                  <div
                    className={`flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center ${
                      isActive
                        ? 'bg-blue-600 text-white'
                        : 'bg-gray-200 text-gray-400'
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                  </div>
                  <div className="flex-1">
                    <p
                      className={`${
                        isActive ? 'text-gray-900' : 'text-gray-500'
                      }`}
                    >
                      {step.label}
                    </p>
                    {isCurrent && (
                      <p className="text-blue-600 mt-1">In progress...</p>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          <div className="pt-4">
            <div className="flex items-center justify-between mb-2">
              <span className="text-gray-600">Progress</span>
              <span className="text-gray-900">{progress}%</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div
                className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
