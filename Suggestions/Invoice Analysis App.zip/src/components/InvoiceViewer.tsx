import { useEffect, useRef, useState } from 'react';
import { ZoomIn, ZoomOut } from 'lucide-react';
import { LineItem } from '../App';

interface InvoiceViewerProps {
  imageUrl: string;
  selectedLineItem: string | null;
  lineItems: LineItem[];
}

export function InvoiceViewer({
  imageUrl,
  selectedLineItem,
  lineItems
}: InvoiceViewerProps) {
  const [zoom, setZoom] = useState(100);
  const containerRef = useRef<HTMLDivElement>(null);

  const selectedItem = lineItems.find((item) => item.id === selectedLineItem);

  useEffect(() => {
    if (selectedItem && containerRef.current) {
      // Scroll to the highlighted area
      const container = containerRef.current;
      const scrollY = (selectedItem.bounds.y / 100) * container.scrollHeight - container.clientHeight / 2;
      container.scrollTo({
        top: scrollY,
        behavior: 'smooth'
      });
    }
  }, [selectedLineItem, selectedItem]);

  const handleZoomIn = () => {
    setZoom((prev) => Math.min(prev + 25, 200));
  };

  const handleZoomOut = () => {
    setZoom((prev) => Math.max(prev - 25, 50));
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-gray-600">
          {selectedLineItem ? 'Click on a row to highlight it' : 'Click on a row to highlight it in the invoice'}
        </p>
        <div className="flex items-center gap-2">
          <button
            onClick={handleZoomOut}
            className="p-2 rounded-lg border border-gray-300 hover:bg-gray-50 transition-colors"
            disabled={zoom <= 50}
          >
            <ZoomOut className="w-4 h-4 text-gray-700" />
          </button>
          <span className="text-gray-700 min-w-[4rem] text-center">{zoom}%</span>
          <button
            onClick={handleZoomIn}
            className="p-2 rounded-lg border border-gray-300 hover:bg-gray-50 transition-colors"
            disabled={zoom >= 200}
          >
            <ZoomIn className="w-4 h-4 text-gray-700" />
          </button>
        </div>
      </div>

      <div
        ref={containerRef}
        className="border border-gray-200 rounded-lg overflow-auto bg-gray-100"
        style={{ maxHeight: '600px' }}
      >
        <div className="relative inline-block min-w-full">
          <img
            src={imageUrl}
            alt="Invoice"
            className="w-full h-auto"
            style={{ transform: `scale(${zoom / 100})`, transformOrigin: 'top left' }}
          />
          {selectedItem && (
            <div
              className="absolute border-4 border-blue-500 bg-blue-500/20 rounded transition-all pointer-events-none"
              style={{
                left: `${selectedItem.bounds.x}%`,
                top: `${selectedItem.bounds.y}%`,
                width: `${selectedItem.bounds.width}%`,
                height: `${selectedItem.bounds.height}%`,
                transform: `scale(${zoom / 100})`,
                transformOrigin: 'top left'
              }}
            />
          )}
        </div>
      </div>
    </div>
  );
}
