import { LineItem } from '../App';

interface InvoiceTableProps {
  lineItems: LineItem[];
  selectedLineItem: string | null;
  onSelectLineItem: (id: string) => void;
}

export function InvoiceTable({
  lineItems,
  selectedLineItem,
  onSelectLineItem
}: InvoiceTableProps) {
  return (
    <div className="overflow-auto max-h-[600px]">
      <table className="w-full">
        <thead className="bg-gray-50 sticky top-0">
          <tr className="border-b border-gray-200">
            <th className="px-4 py-3 text-left text-gray-700">Description</th>
            <th className="px-4 py-3 text-right text-gray-700">Qty</th>
            <th className="px-4 py-3 text-right text-gray-700">Unit Price</th>
            <th className="px-4 py-3 text-right text-gray-700">Amount</th>
          </tr>
        </thead>
        <tbody>
          {lineItems.map((item) => (
            <tr
              key={item.id}
              className={`border-b border-gray-100 cursor-pointer transition-colors ${
                selectedLineItem === item.id
                  ? 'bg-blue-50 hover:bg-blue-100'
                  : 'hover:bg-gray-50'
              }`}
              onClick={() => onSelectLineItem(item.id)}
            >
              <td className="px-4 py-3 text-gray-900">{item.description}</td>
              <td className="px-4 py-3 text-right text-gray-900">{item.quantity}</td>
              <td className="px-4 py-3 text-right text-gray-900">
                ${item.unitPrice.toFixed(2)}
              </td>
              <td className="px-4 py-3 text-right text-gray-900">
                ${item.amount.toFixed(2)}
              </td>
            </tr>
          ))}
        </tbody>
        <tfoot className="bg-gray-50 sticky bottom-0">
          <tr className="border-t-2 border-gray-300">
            <td colSpan={3} className="px-4 py-3 text-right text-gray-900">
              Total:
            </td>
            <td className="px-4 py-3 text-right text-gray-900">
              ${lineItems.reduce((sum, item) => sum + item.amount, 0).toFixed(2)}
            </td>
          </tr>
        </tfoot>
      </table>
    </div>
  );
}
