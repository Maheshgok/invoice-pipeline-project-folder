import { useState } from 'react';
import { InvoiceUploader } from './components/InvoiceUploader';
import { AnalysisProgress } from './components/AnalysisProgress';
import { InvoiceTable } from './components/InvoiceTable';
import { InvoiceViewer } from './components/InvoiceViewer';

export interface LineItem {
  id: string;
  description: string;
  quantity: number;
  unitPrice: number;
  amount: number;
  bounds: {
    x: number;
    y: number;
    width: number;
    height: number;
  };
}

export interface InvoiceData {
  invoiceNumber: string;
  date: string;
  vendor: string;
  total: number;
  lineItems: LineItem[];
}

type AnalysisState = 'idle' | 'uploading' | 'analyzing' | 'complete';

export default function App() {
  const [invoiceImage, setInvoiceImage] = useState<string | null>(null);
  const [analysisState, setAnalysisState] = useState<AnalysisState>('idle');
  const [progress, setProgress] = useState(0);
  const [invoiceData, setInvoiceData] = useState<InvoiceData | null>(null);
  const [selectedLineItem, setSelectedLineItem] = useState<string | null>(null);

  const handleFileUpload = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const imageUrl = e.target?.result as string;
      setInvoiceImage(imageUrl);
      startAnalysis();
    };
    reader.readAsDataURL(file);
  };

  const startAnalysis = () => {
    setAnalysisState('uploading');
    setProgress(0);

    // Simulate upload
    setTimeout(() => {
      setProgress(30);
      setAnalysisState('analyzing');

      // Simulate OCR processing
      setTimeout(() => {
        setProgress(60);

        // Simulate data extraction
        setTimeout(() => {
          setProgress(100);
          setAnalysisState('complete');

          // Mock invoice data
          const mockData: InvoiceData = {
            invoiceNumber: 'INV-2024-0542',
            date: '2024-12-01',
            vendor: 'Tech Supplies Inc.',
            total: 2847.50,
            lineItems: [
              {
                id: '1',
                description: 'Dell UltraSharp Monitor 27"',
                quantity: 2,
                unitPrice: 450.00,
                amount: 900.00,
                bounds: { x: 5, y: 25, width: 90, height: 8 }
              },
              {
                id: '2',
                description: 'Logitech MX Master 3 Mouse',
                quantity: 5,
                unitPrice: 99.99,
                amount: 499.95,
                bounds: { x: 5, y: 35, width: 90, height: 8 }
              },
              {
                id: '3',
                description: 'Mechanical Keyboard RGB',
                quantity: 3,
                unitPrice: 149.00,
                amount: 447.00,
                bounds: { x: 5, y: 45, width: 90, height: 8 }
              },
              {
                id: '4',
                description: 'USB-C Docking Station',
                quantity: 2,
                unitPrice: 250.00,
                amount: 500.00,
                bounds: { x: 5, y: 55, width: 90, height: 8 }
              },
              {
                id: '5',
                description: 'Webcam HD 1080p',
                quantity: 4,
                unitPrice: 125.64,
                amount: 502.56,
                bounds: { x: 5, y: 65, width: 90, height: 8 }
              }
            ]
          };

          setInvoiceData(mockData);
        }, 1000);
      }, 1000);
    }, 800);
  };

  const handleReset = () => {
    setInvoiceImage(null);
    setAnalysisState('idle');
    setProgress(0);
    setInvoiceData(null);
    setSelectedLineItem(null);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white border-b border-gray-200">
        <div className="max-w-[1600px] mx-auto px-6 py-4">
          <h1 className="text-gray-900">Invoice Analysis</h1>
        </div>
      </header>

      <main className="max-w-[1600px] mx-auto px-6 py-8">
        {analysisState === 'idle' && (
          <InvoiceUploader onFileUpload={handleFileUpload} />
        )}

        {(analysisState === 'uploading' || analysisState === 'analyzing') && (
          <AnalysisProgress progress={progress} state={analysisState} />
        )}

        {analysisState === 'complete' && invoiceData && invoiceImage && (
          <div className="space-y-6">
            <div className="bg-white rounded-lg border border-gray-200 p-6">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h2 className="text-gray-900">Analysis Complete</h2>
                  <p className="text-gray-600 mt-1">
                    Invoice {invoiceData.invoiceNumber} from {invoiceData.vendor}
                  </p>
                </div>
                <button
                  onClick={handleReset}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  Analyze New Invoice
                </button>
              </div>

              <div className="grid grid-cols-3 gap-4 pt-4 border-t border-gray-200">
                <div>
                  <p className="text-gray-600">Invoice Number</p>
                  <p className="text-gray-900 mt-1">{invoiceData.invoiceNumber}</p>
                </div>
                <div>
                  <p className="text-gray-600">Date</p>
                  <p className="text-gray-900 mt-1">{invoiceData.date}</p>
                </div>
                <div>
                  <p className="text-gray-600">Total</p>
                  <p className="text-gray-900 mt-1">${invoiceData.total.toFixed(2)}</p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-6">
              <div className="bg-white rounded-lg border border-gray-200 p-6">
                <h3 className="text-gray-900 mb-4">Line Items</h3>
                <InvoiceTable
                  lineItems={invoiceData.lineItems}
                  selectedLineItem={selectedLineItem}
                  onSelectLineItem={setSelectedLineItem}
                />
              </div>

              <div className="bg-white rounded-lg border border-gray-200 p-6">
                <h3 className="text-gray-900 mb-4">Invoice Preview</h3>
                <InvoiceViewer
                  imageUrl={invoiceImage}
                  selectedLineItem={selectedLineItem}
                  lineItems={invoiceData.lineItems}
                />
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
