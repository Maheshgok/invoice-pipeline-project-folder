
  # Invoice Analysis App

  This is a code bundle for Invoice Analysis App. The original project is available at https://www.figma.com/design/nDzA8ZROPeB8mvzz0cylhJ/Invoice-Analysis-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  